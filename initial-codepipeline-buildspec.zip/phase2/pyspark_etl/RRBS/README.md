**Lyca ETL pipeline**

This ETL pipeline is consist reusable code for multiple module.

**Build the project**

To create the egg file for this project run the following command in project root directory.

make build 