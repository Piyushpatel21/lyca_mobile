select 'dim_rrbs_data_cdrtype',count(*) from uk_rrbs_dm.dim_rrbs_data_cdrtype union
select 'dim_rrbs_data_serviceid',count(*) from uk_rrbs_dm.dim_rrbs_data_serviceid union
select 'dim_rrbs_data_subscribertype',count(*) from uk_rrbs_dm.dim_rrbs_data_subscribertype union
select 'dim_rrbs_sms_buckettype',count(*) from uk_rrbs_dm.dim_rrbs_sms_buckettype union
select 'dim_rrbs_sms_calltype',count(*) from uk_rrbs_dm.dim_rrbs_sms_calltype union
select 'dim_rrbs_sms_cdrtype',count(*) from uk_rrbs_dm.dim_rrbs_sms_cdrtype union
select 'dim_rrbs_sms_serviceid',count(*) from uk_rrbs_dm.dim_rrbs_sms_serviceid union
select 'dim_rrbs_sms_smsfeature',count(*) from uk_rrbs_dm.dim_rrbs_sms_smsfeature union
select 'dim_rrbs_sms_subscribertype',count(*) from uk_rrbs_dm.dim_rrbs_sms_subscribertype union
select 'dim_rrbs_voice_cdrtype',count(*) from uk_rrbs_dm.dim_rrbs_voice_cdrtype union
select 'dim_rrbs_voice_serviceid',count(*) from uk_rrbs_dm.dim_rrbs_voice_serviceid union
select 'dim_rrbs_voice_subscribertype',count(*) from uk_rrbs_dm.dim_rrbs_voice_subscribertype union
select 'dim_rrbs_voice_calltype',count(*) from uk_rrbs_dm.dim_rrbs_voice_calltype union
select 'dim_rrbs_voice_buckettype',count(*) from uk_rrbs_dm.dim_rrbs_voice_buckettype union
select 'dim_rrbs_voice_callfeature',count(*) from uk_rrbs_dm.dim_rrbs_voice_callfeature union
select 'dim_rrbs_voice_failcause',count(*) from uk_rrbs_dm.dim_rrbs_voice_failcause union
select 'dim_rrbs_topup_operationcode',count(*) from uk_rrbs_dm.dim_rrbs_topup_operationcode union
select 'dim_rrbs_topup_serviceid',count(*) from uk_rrbs_dm.dim_rrbs_topup_serviceid union
select 'dim_rrbs_topup_bundleCategory',count(*) from uk_rrbs_dm.dim_rrbs_topup_bundleCategory union
select 'dim_rrbs_topup_codetext',count(*) from uk_rrbs_dm.dim_rrbs_topup_codetext union
select 'dim_rrbs_data_codetext',count(*) from uk_rrbs_dm.dim_rrbs_data_codetext union
select 'dim_rrbs_sms_codetext',count(*) from uk_rrbs_dm.dim_rrbs_sms_codetext union
select 'dim_rrbs_voice_codetext',count(*) from uk_rrbs_dm.dim_rrbs_voice_codetext ;




